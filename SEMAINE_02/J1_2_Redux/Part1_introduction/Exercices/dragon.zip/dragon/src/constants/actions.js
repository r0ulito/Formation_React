// constantes reducer dragon
export const SET_DRAGON = "SET_DRAGON" ;
export const ADD_DRAGON = "ADD_DRAGON" ;
export const DELETE_DRAGON = "DELETE_DRAGON" ;
export const REVERSE_DRAGON_LIST = "REVERSE_DRAGON_LIST";

// constante reducer log
export const SET_LOG = "SET_LOG";
