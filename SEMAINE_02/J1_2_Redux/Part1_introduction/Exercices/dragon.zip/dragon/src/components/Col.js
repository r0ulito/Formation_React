import React from 'react';

const Col = ({children}) => {
    return (
       <div className="Col-main">
           {children}
       </div>
    );
}

export default Col;
