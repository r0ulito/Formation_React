// reducer dragon
export const SET_DRAGON = "SET_DRAGON" ;
export const ADD_DRAGON = "ADD_DRAGON" ;
export const DELETE_DRAGON = "DELETE_DRAGON" ;
export const REVERSE_DRAGON_LIST = "REVERSE_DRAGON_LIST";

// reducer log
export const SET_LOG = "SET_LOG";

// reducer knight
export const SET_KNIGHT = "SET_KNIGHT" ;
export const ADD_KNIGHT = "ADD_KNIGHT" ;
export const DELETE_KNIGHT = "DELETE_KNIGHT" ;

// reducer chrono
export const SET_COUNTER = 'SET_COUNTER';
export const STOP_START_COUNTER = 'STOP_START_COUNTER';

export const TIME =  1000;
